﻿using Windows.ApplicationModel.DataTransfer;

namespace App2.Models
{
    public class DragDropData
    {
        public DataPackageOperation AcceptedOperation { get; set; }

        public DataPackageView DataView { get; set; }
    }
}

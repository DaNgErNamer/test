﻿namespace App2.Core.Models
{
    public class SampleImage
    {
        public string ID { get; set; }

        public string Name { get; set; }

        public string Source { get; set; }
    }
}
